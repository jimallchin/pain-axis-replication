Raw trial logs, one trial per line, at the paths under runs/ that the analysis scripts read.
From the repository root: ./reproduce.sh logs   (unpacks this file into runs/)
replication/: the released script on three button pairs, and the yoked arm.
conditions/: every first-choice condition; work_<direction> names the steering direction.
matched_history/: the matched-history assay and its controls.
